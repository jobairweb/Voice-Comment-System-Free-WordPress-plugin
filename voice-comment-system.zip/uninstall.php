<?php
/**
 * Uninstall Voice Comment System Plugin
 * 
 * This file runs when the plugin is deleted from WordPress
 */

// Exit if uninstall not called from WordPress
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Delete plugin options
delete_option('vcs_settings');

// Delete all voice comment metadata
global $wpdb;

$wpdb->query("DELETE FROM {$wpdb->commentmeta} WHERE meta_key = '_voice_comment_audio_url'");
$wpdb->query("DELETE FROM {$wpdb->commentmeta} WHERE meta_key = '_voice_comment_text'");

// Delete voice files directory
$upload_dir = wp_upload_dir();
$voice_dir = $upload_dir['basedir'] . '/voice-comments';

if (file_exists($voice_dir)) {
    // Delete all files in directory
    $files = glob($voice_dir . '/*');
    foreach ($files as $file) {
        if (is_file($file)) {
            unlink($file);
        }
    }
    
    // Remove directory
    rmdir($voice_dir);
}

// Delete transients
$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_vcs_temp_%'");
$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_vcs_temp_%'");

// Clear any cached data
wp_cache_flush();