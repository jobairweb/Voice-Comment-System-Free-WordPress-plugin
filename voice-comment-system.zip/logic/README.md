# Voice Comment System (Free) - WordPress Plugin

🎙️ **Allow visitors to record and submit voice comments using their browser microphone — completely FREE with no paid API required!**

## Features

✅ **Browser-based Recording** - Uses MediaRecorder API (no external service)  
✅ **Speech-to-Text** - Automatic transcription using Web Speech API (Chrome/Edge)  
✅ **Audio Playback** - Preview recordings before submitting  
✅ **Multi-language Support** - English, Bengali, Hindi, Spanish, and more  
✅ **Secure Upload** - Nonce verification and file size limits  
✅ **Auto-delete** - Remove audio files when comments are deleted  
✅ **Shortcode Support** - `[voice_comment_form]` to add anywhere  
✅ **Responsive Design** - Works on desktop and mobile  
✅ **No Dependencies** - Pure JavaScript, no jQuery required for core functionality

---

## Installation

### Method 1: Manual Upload

1. Download the plugin folder `voice-comment-system`
2. Upload to `/wp-content/plugins/` directory
3. Activate the plugin through 'Plugins' menu in WordPress
4. Go to **Settings → Voice Comments** to configure

### Method 2: ZIP Upload

1. Zip the `voice-comment-system` folder
2. Go to **WordPress Admin → Plugins → Add New → Upload Plugin**
3. Upload the ZIP file and activate

---

## File Structure

```
voice-comment-system/
├── voice-comment-system.php    (Main plugin file)
├── assets/
│   ├── css/
│   │   └── style.css           (Styling)
│   └── js/
│       └── recorder.js         (Recording & transcription logic)
└── README.md                   (This file)
```

---

## Configuration

Navigate to **Settings → Voice Comments** in WordPress admin:

### Available Settings:

| Setting | Description | Default |
|---------|-------------|---------|
| **Max Recording Duration** | Maximum seconds users can record | 60 seconds |
| **Enable Transcription** | Auto-convert speech to text (Chrome/Edge only) | Yes |
| **Allowed Formats** | Comma-separated audio formats | webm,mp3,wav |
| **Auto-delete Audio** | Delete audio files when comment is deleted | Yes |
| **Require Login** | Only logged-in users can record voice | No |
| **Language** | Speech recognition language | en-US |

---

## Usage

### Automatic Display

The voice recorder button appears automatically below the comment form on all posts/pages where comments are enabled.

### Using Shortcode

Place this shortcode anywhere to add the voice recorder:

```
[voice_comment_form]
```

**Example:** Add to a custom page template, widget, or Gutenberg block.

---

## How It Works

### For Users:

1. Click **"🎙 Record Voice Comment"**
2. Click **"Start Recording"** (allow microphone access)
3. Speak your comment (up to 60 seconds)
4. Click **"Stop Recording"**
5. **Play** to preview, or **Re-record** if needed
6. If transcription is enabled, text appears automatically in the comment box
7. Fill in Name/Email and submit the comment

### Technical Flow:

1. **Recording:** MediaRecorder API captures audio as WebM/MP4
2. **Transcription:** Web Speech API (SpeechRecognition) converts speech to text in real-time
3. **Upload:** Audio converted to base64 and sent via AJAX to WordPress
4. **Storage:** Audio saved to `/wp-content/uploads/voice-comments/`
5. **Comment Meta:** Audio URL and transcript saved as comment metadata
6. **Display:** Audio player and transcript shown with the comment

---

## Browser Compatibility

| Feature | Chrome | Edge | Firefox | Safari | Opera |
|---------|--------|------|---------|--------|-------|
| **Audio Recording** | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Speech Recognition** | ✅ | ✅ | ❌ | ❌ | ✅ |

**Note:** Speech-to-text only works in Chromium-based browsers (Chrome, Edge, Opera). Firefox and Safari users can still record audio.

---

## Security Features

🔒 **Nonce Verification** - All AJAX requests are verified  
🔒 **File Size Limit** - Maximum 2MB per audio file  
🔒 **Sanitization** - All inputs sanitized and escaped  
🔒 **Login Requirement** - Optional: Restrict to logged-in users only  
🔒 **File Type Validation** - Only audio formats accepted

---

## Troubleshooting

### "Microphone access denied"
- User must allow microphone permission in browser
- Check browser settings: `chrome://settings/content/microphone`

### Transcription not working
- Only works in Chrome/Edge/Opera browsers
- Check if "Enable Transcription" is ON in settings
- Ensure microphone has clear audio input

### Audio not uploading
- Check file size (max 2MB)
- Verify `/wp-content/uploads/voice-comments/` folder is writable
- Check PHP `upload_max_filesize` and `post_max_size` settings

### Audio not playing
- Browser must support HTML5 `<audio>` element
- Check audio file format compatibility
- Try regenerating recording

---

## Customization

### Change Button Text

Edit in `voice-comment-system.php`:

```php
🎙 Record Voice Comment
```

### Modify Styles

Edit `assets/css/style.css` to change colors, sizes, etc.

### Adjust Max File Size

In `voice-comment-system.php`, find:

```php
if (strlen($audio_binary) > 2097152) { // 2MB
```

Change `2097152` to desired bytes (e.g., `5242880` for 5MB)

---

## Hooks & Filters

### Custom Audio Save Location

```php
add_filter('vcs_audio_directory', function($dir) {
    return '/custom-path/voices/';
});
```

### Modify Allowed Formats

```php
add_filter('vcs_allowed_formats', function($formats) {
    return array('webm', 'mp3', 'ogg');
});
```

---

## Shortcode Attributes

```php
[voice_comment_form post_id="123"]
```

Displays voice recorder for specific post ID.

---

## Changelog

### Version 1.0.0
- Initial release
- MediaRecorder API integration
- Web Speech API for transcription
- Admin settings page
- Multi-language support
- Shortcode support
- Auto-delete functionality

---

## Credits

**Developer:** Your Name  
**License:** GPL v2 or later  
**Requires:** WordPress 5.0+  
**Tested up to:** WordPress 6.6  

---

## Support

For issues, suggestions, or contributions:
- GitHub: 
- Email: joair.dev@gmail.com
- Website:

---

## License

This plugin is licensed under the GPL v2 or later.

```
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.
```

---

**Made with ❤️ for the WordPress Community**