<?php
/**
 * Plugin Name: wordpress Voice Comment  
 * Plugin URI: 
 * Description: Let visitors record and post voice comments using browser mic (no paid API).
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: 
 * License: GPL v2 or later
 * Text Domain: voice-comment-system
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('VCS_VERSION', '1.0.0');
define('VCS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('VCS_PLUGIN_URL', plugin_dir_url(__FILE__));

class Voice_Comment_System {
    
    public function __construct() {
        // Activation/Deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // Admin menu
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        
        // Frontend hooks
        add_action('comment_form_after', array($this, 'add_voice_comment_button'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_scripts'));
        
        // Handle voice upload
        add_action('wp_ajax_vcs_upload_voice', array($this, 'handle_voice_upload'));
        add_action('wp_ajax_nopriv_vcs_upload_voice', array($this, 'handle_voice_upload'));
        
        // Display voice comments
        add_filter('comment_text', array($this, 'display_voice_comment'), 10, 2);
        
        // Delete audio on comment delete
        add_action('delete_comment', array($this, 'delete_voice_file'));
        
        // Shortcode
        add_shortcode('voice_comment_form', array($this, 'voice_comment_form_shortcode'));
    }
    
    public function activate() {
        // Create upload directory
        $upload_dir = wp_upload_dir();
        $voice_dir = $upload_dir['basedir'] . '/voice-comments';
        
        if (!file_exists($voice_dir)) {
            wp_mkdir_p($voice_dir);
        }
        
        // Set default options
        if (!get_option('vcs_settings')) {
            update_option('vcs_settings', array(
                'max_duration' => 60,
                'enable_transcription' => 'yes',
                'allowed_formats' => 'webm,mp3,wav',
                'auto_delete' => 'yes',
                'require_login' => 'no',
                'language' => 'en-US'
            ));
        }
    }
    
    public function deactivate() {
        // Cleanup if needed
    }
    
    public function add_admin_menu() {
        add_options_page(
            'Voice Comments Settings',
            'Voice Comments',
            'manage_options',
            'voice-comment-settings',
            array($this, 'settings_page')
        );
    }
    
    public function register_settings() {
        register_setting('vcs_settings_group', 'vcs_settings');
    }
    
    public function settings_page() {
        $settings = get_option('vcs_settings');
        ?>
        <div class="wrap">
            <h1>Voice Comment System Settings</h1>
            <form method="post" action="options.php">
                <?php settings_fields('vcs_settings_group'); ?>
                <table class="form-table">
                    <tr>
                        <th scope="row">Max Recording Duration (seconds)</th>
                        <td>
                            <input type="number" name="vcs_settings[max_duration]" 
                                   value="<?php echo esc_attr($settings['max_duration']); ?>" min="10" max="300" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Enable Transcription</th>
                        <td>
                            <input type="checkbox" name="vcs_settings[enable_transcription]" 
                                   value="yes" <?php checked($settings['enable_transcription'], 'yes'); ?> />
                            <p class="description">Use browser's speech recognition (Chrome/Edge only)</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Allowed Formats</th>
                        <td>
                            <input type="text" name="vcs_settings[allowed_formats]" 
                                   value="<?php echo esc_attr($settings['allowed_formats']); ?>" 
                                   placeholder="webm,mp3,wav" style="width: 300px;" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Auto-delete Audio on Comment Delete</th>
                        <td>
                            <input type="checkbox" name="vcs_settings[auto_delete]" 
                                   value="yes" <?php checked($settings['auto_delete'], 'yes'); ?> />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Require Login</th>
                        <td>
                            <input type="checkbox" name="vcs_settings[require_login]" 
                                   value="yes" <?php checked($settings['require_login'], 'yes'); ?> />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Speech Recognition Language</th>
                        <td>
                            <select name="vcs_settings[language]">
                                <option value="en-US" <?php selected($settings['language'], 'en-US'); ?>>English (US)</option>
                                <option value="en-GB" <?php selected($settings['language'], 'en-GB'); ?>>English (UK)</option>
                                <option value="bn-BD" <?php selected($settings['language'], 'bn-BD'); ?>>বাংলা (Bangladesh)</option>
                                <option value="hi-IN" <?php selected($settings['language'], 'hi-IN'); ?>>हिन्दी (India)</option>
                                <option value="es-ES" <?php selected($settings['language'], 'es-ES'); ?>>Español</option>
                            </select>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
    
    public function enqueue_frontend_scripts() {
        if (is_singular() && comments_open()) {
            wp_enqueue_style('vcs-style', VCS_PLUGIN_URL . 'assets/css/style.css', array(), VCS_VERSION);
            wp_enqueue_script('vcs-recorder', VCS_PLUGIN_URL . 'assets/js/recorder.js', array('jquery'), VCS_VERSION, true);
            
            $settings = get_option('vcs_settings');
            wp_localize_script('vcs-recorder', 'vcsSettings', array(
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('vcs_upload_nonce'),
                'maxDuration' => intval($settings['max_duration']),
                'enableTranscription' => $settings['enable_transcription'],
                'language' => $settings['language'],
                'postId' => get_the_ID()
            ));
        }
    }
    
    public function add_voice_comment_button() {
        $settings = get_option('vcs_settings');
        
        if ($settings['require_login'] === 'yes' && !is_user_logged_in()) {
            return;
        }
        ?>
        <div id="vcs-voice-recorder">
            <button type="button" id="vcs-record-btn" class="vcs-btn">
                🎙 Record Voice Comment
            </button>
            <div id="vcs-recorder-interface" style="display: none;">
                <div class="vcs-controls">
                    <button type="button" id="vcs-start-recording" class="vcs-btn vcs-btn-start">Start Recording</button>
                    <button type="button" id="vcs-stop-recording" class="vcs-btn vcs-btn-stop" disabled>Stop Recording</button>
                    <button type="button" id="vcs-play-recording" class="vcs-btn vcs-btn-play" disabled>Play</button>
                    <button type="button" id="vcs-rerecord" class="vcs-btn vcs-btn-rerecord" disabled>Re-record</button>
                    <button type="button" id="vcs-cancel" class="vcs-btn vcs-btn-cancel">Cancel</button>
                </div>
                <div class="vcs-timer">
                    <span id="vcs-time-display">00:00</span> / <span id="vcs-max-time">00:<?php echo str_pad($settings['max_duration'], 2, '0', STR_PAD_LEFT); ?></span>
                </div>
                <div id="vcs-waveform"></div>
                <audio id="vcs-audio-preview" controls style="display: none; width: 100%; margin-top: 10px;"></audio>
                <div id="vcs-transcription" class="vcs-transcription" style="display: none;">
                    <strong>Transcription:</strong>
                    <p id="vcs-transcript-text"></p>
                </div>
                <div id="vcs-status" class="vcs-status"></div>
                <input type="hidden" id="vcs-audio-data" />
                <input type="hidden" id="vcs-transcript-data" />
            </div>
        </div>
        <?php
    }
    
    public function handle_voice_upload() {
        check_ajax_referer('vcs_upload_nonce', 'nonce');
        
        $settings = get_option('vcs_settings');
        
        // Check login requirement
        if ($settings['require_login'] === 'yes' && !is_user_logged_in()) {
            wp_send_json_error('You must be logged in to post voice comments.');
        }
        
        $post_id = intval($_POST['post_id']);
        $audio_data = sanitize_text_field($_POST['audio_data']);
        $transcript = sanitize_textarea_field($_POST['transcript']);
        
        // Decode base64 audio
        $audio_binary = base64_decode(preg_replace('#^data:audio/\w+;base64,#i', '', $audio_data));
        
        if (!$audio_binary) {
            wp_send_json_error('Invalid audio data.');
        }
        
        // Check file size (2MB limit)
        if (strlen($audio_binary) > 2097152) {
            wp_send_json_error('Audio file too large. Maximum 2MB allowed.');
        }
        
        // Prepare upload
        $upload_dir = wp_upload_dir();
        $voice_dir = $upload_dir['basedir'] . '/voice-comments';
        
        if (!file_exists($voice_dir)) {
            wp_mkdir_p($voice_dir);
        }
        
        $filename = 'voice-' . $post_id . '-' . time() . '-' . wp_generate_password(8, false) . '.webm';
        $filepath = $voice_dir . '/' . $filename;
        
        // Save file
        file_put_contents($filepath, $audio_binary);
        
        $audio_url = $upload_dir['baseurl'] . '/voice-comments/' . $filename;
        
        // Store temporarily in session or transient
        $temp_data = array(
            'audio_url' => $audio_url,
            'transcript' => $transcript,
            'post_id' => $post_id
        );
        
        // Save as transient with unique key
        $temp_key = 'vcs_temp_' . md5($audio_url);
        set_transient($temp_key, $temp_data, 3600); // 1 hour expiry
        
        wp_send_json_success(array(
            'temp_key' => $temp_key,
            'message' => 'Voice uploaded successfully!'
        ));
    }
    
    public function display_voice_comment($comment_text, $comment) {
        $audio_url = get_comment_meta($comment->comment_ID, '_voice_comment_audio_url', true);
        $transcript = get_comment_meta($comment->comment_ID, '_voice_comment_text', true);
        
        if ($audio_url) {
            $voice_html = '<div class="voice-comment">';
            $voice_html .= '<audio controls src="' . esc_url($audio_url) . '"></audio>';
            
            if ($transcript) {
                $voice_html .= '<p class="voice-transcript"><strong>Transcription:</strong> ' . esc_html($transcript) . '</p>';
            }
            
            $voice_html .= '</div>';
            
            return $voice_html . $comment_text;
        }
        
        return $comment_text;
    }
    
    public function delete_voice_file($comment_id) {
        $settings = get_option('vcs_settings');
        
        if ($settings['auto_delete'] === 'yes') {
            $audio_url = get_comment_meta($comment_id, '_voice_comment_audio_url', true);
            
            if ($audio_url) {
                $upload_dir = wp_upload_dir();
                $file_path = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $audio_url);
                
                if (file_exists($file_path)) {
                    unlink($file_path);
                }
            }
        }
    }
    
    public function voice_comment_form_shortcode($atts) {
        ob_start();
        $this->add_voice_comment_button();
        return ob_get_clean();
    }
}

// Initialize plugin
new Voice_Comment_System();

// Hook to save voice data when comment is posted
add_action('comment_post', 'vcs_save_voice_data', 10, 2);

function vcs_save_voice_data($comment_id, $comment_approved) {
    if (isset($_POST['vcs_temp_key'])) {
        $temp_key = sanitize_text_field($_POST['vcs_temp_key']);
        $temp_data = get_transient($temp_key);
        
        if ($temp_data) {
            add_comment_meta($comment_id, '_voice_comment_audio_url', esc_url_raw($temp_data['audio_url']));
            add_comment_meta($comment_id, '_voice_comment_text', sanitize_textarea_field($temp_data['transcript']));
            
            delete_transient($temp_key);
        }
    }
}