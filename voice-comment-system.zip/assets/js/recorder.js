jQuery(document).ready(function($) {
    let mediaRecorder;
    let audioChunks = [];
    let audioBlob;
    let recordingTimer;
    let recordingSeconds = 0;
    let recognition;
    let transcript = '';
    let stream;
    
    const maxDuration = vcsSettings.maxDuration || 60;
    const enableTranscription = vcsSettings.enableTranscription === 'yes';
    const language = vcsSettings.language || 'en-US';
    
    // Toggle recorder interface
    $('#vcs-record-btn').on('click', function() {
        $('#vcs-recorder-interface').slideToggle();
        $(this).text($(this).text().includes('Record') ? '❌ Close Recorder' : '🎙 Record Voice Comment');
    });
    
    // Start recording
    $('#vcs-start-recording').on('click', async function() {
        try {
            // Request microphone access
            stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            
            // Initialize MediaRecorder
            const mimeType = MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : 'audio/mp4';
            mediaRecorder = new MediaRecorder(stream, { mimeType: mimeType });
            
            audioChunks = [];
            recordingSeconds = 0;
            transcript = '';
            
            mediaRecorder.ondataavailable = (event) => {
                audioChunks.push(event.data);
            };
            
            mediaRecorder.onstop = () => {
                audioBlob = new Blob(audioChunks, { type: mimeType });
                const audioUrl = URL.createObjectURL(audioBlob);
                
                $('#vcs-audio-preview').attr('src', audioUrl).show();
                $('#vcs-play-recording').prop('disabled', false);
                $('#vcs-rerecord').prop('disabled', false);
                
                // Convert to base64
                const reader = new FileReader();
                reader.readAsDataURL(audioBlob);
                reader.onloadend = function() {
                    $('#vcs-audio-data').val(reader.result);
                };
                
                // Stop all tracks
                if (stream) {
                    stream.getTracks().forEach(track => track.stop());
                }
            };
            
            // Start recording
            mediaRecorder.start();
            
            // Update UI
            $(this).prop('disabled', true);
            $('#vcs-stop-recording').prop('disabled', false);
            $('#vcs-status').text('🔴 Recording...').css('color', 'red');
            
            // Start timer
            recordingTimer = setInterval(function() {
                recordingSeconds++;
                updateTimer();
                
                // Auto-stop at max duration
                if (recordingSeconds >= maxDuration) {
                    $('#vcs-stop-recording').click();
                }
            }, 1000);
            
            // Start speech recognition
            if (enableTranscription && 'webkitSpeechRecognition' in window) {
                startSpeechRecognition();
            }
            
        } catch (error) {
            console.error('Error accessing microphone:', error);
            $('#vcs-status').text('❌ Microphone access denied. Please allow microphone access.').css('color', 'red');
        }
    });
    
    // Stop recording
    $('#vcs-stop-recording').on('click', function() {
        if (mediaRecorder && mediaRecorder.state !== 'inactive') {
            mediaRecorder.stop();
            clearInterval(recordingTimer);
            
            // Stop speech recognition
            if (recognition) {
                recognition.stop();
            }
            
            // Update UI
            $('#vcs-start-recording').prop('disabled', false);
            $(this).prop('disabled', true);
            $('#vcs-status').text('✅ Recording stopped. You can play, re-record, or submit.').css('color', 'green');
        }
    });
    
    // Play recording
    $('#vcs-play-recording').on('click', function() {
        const audio = document.getElementById('vcs-audio-preview');
        if (audio.paused) {
            audio.play();
            $(this).text('⏸ Pause');
        } else {
            audio.pause();
            $(this).text('▶ Play');
        }
    });
    
    // Re-record
    $('#vcs-rerecord').on('click', function() {
        // Reset everything
        audioChunks = [];
        audioBlob = null;
        transcript = '';
        recordingSeconds = 0;
        
        $('#vcs-audio-preview').attr('src', '').hide();
        $('#vcs-audio-data').val('');
        $('#vcs-transcript-data').val('');
        $('#vcs-transcription').hide();
        $('#vcs-time-display').text('00:00');
        $('#vcs-status').text('');
        
        $('#vcs-play-recording').prop('disabled', true).text('▶ Play');
        $('#vcs-rerecord').prop('disabled', true);
        $('#vcs-start-recording').prop('disabled', false);
    });
    
    // Cancel
    $('#vcs-cancel').on('click', function() {
        $('#vcs-rerecord').click();
        $('#vcs-recorder-interface').slideUp();
        $('#vcs-record-btn').text('🎙 Record Voice Comment');
        
        // Stop stream if active
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
        }
    });
    
    // Update timer display
    function updateTimer() {
        const minutes = Math.floor(recordingSeconds / 60);
        const seconds = recordingSeconds % 60;
        $('#vcs-time-display').text(
            String(minutes).padStart(2, '0') + ':' + String(seconds).padStart(2, '0')
        );
    }
    
    // Speech recognition
    function startSpeechRecognition() {
        if (!('webkitSpeechRecognition' in window)) {
            return;
        }
        
        recognition = new webkitSpeechRecognition();
        recognition.continuous = true;
        recognition.interimResults = true;
        recognition.lang = language;
        
        recognition.onstart = function() {
            $('#vcs-transcription').show();
            $('#vcs-transcript-text').text('Listening...');
        };
        
        recognition.onresult = function(event) {
            let interimTranscript = '';
            let finalTranscript = '';
            
            for (let i = event.resultIndex; i < event.results.length; i++) {
                const transcriptPart = event.results[i][0].transcript;
                if (event.results[i].isFinal) {
                    finalTranscript += transcriptPart + ' ';
                } else {
                    interimTranscript += transcriptPart;
                }
            }
            
            transcript = finalTranscript || interimTranscript;
            $('#vcs-transcript-text').text(transcript || 'Listening...');
            $('#vcs-transcript-data').val(transcript);
            
            // Update comment textarea
            const commentBox = $('#comment');
            if (commentBox.length && transcript) {
                commentBox.val(transcript);
            }
        };
        
        recognition.onerror = function(event) {
            console.error('Speech recognition error:', event.error);
        };
        
        recognition.start();
    }
    
    // Handle comment form submission
    $('#commentform').on('submit', function(e) {
        const audioData = $('#vcs-audio-data').val();
        
        if (audioData) {
            e.preventDefault();
            
            const $form = $(this);
            const $submitBtn = $form.find('[type="submit"]');
            
            // Disable submit button
            $submitBtn.prop('disabled', true).val('Uploading voice...');
            $('#vcs-status').text('⏳ Uploading voice comment...').css('color', 'blue');
            
            // Upload voice first
            $.ajax({
                url: vcsSettings.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'vcs_upload_voice',
                    nonce: vcsSettings.nonce,
                    post_id: vcsSettings.postId,
                    audio_data: audioData,
                    transcript: $('#vcs-transcript-data').val()
                },
                success: function(response) {
                    if (response.success) {
                        // Add temp key to form
                        $('<input>').attr({
                            type: 'hidden',
                            name: 'vcs_temp_key',
                            value: response.data.temp_key
                        }).appendTo($form);
                        
                        // Submit form
                        $form.off('submit').submit();
                    } else {
                        alert('Error: ' + response.data);
                        $submitBtn.prop('disabled', false).val('Post Comment');
                        $('#vcs-status').text('❌ Upload failed.').css('color', 'red');
                    }
                },
                error: function() {
                    alert('Failed to upload voice. Please try again.');
                    $submitBtn.prop('disabled', false).val('Post Comment');
                    $('#vcs-status').text('❌ Upload failed.').css('color', 'red');
                }
            });
        }
    });
});